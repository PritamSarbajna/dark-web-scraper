
![Black Minimal Business Personal Profile Linkedin Banner](https://github.com/PritamSarbajna/dark-web-scraper/assets/90236635/676a6e65-5be3-4bda-a04c-47162ad14f51)

<div align="center" >
  
![Python](https://img.shields.io/badge/python-3670A0?style=for-the-badge&logo=python&logoColor=ffdd54)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
![Kali](https://img.shields.io/badge/Kali-268BEE?style=for-the-badge&logo=kalilinux&logoColor=white)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
![Linux](https://img.shields.io/badge/Linux-FCC624?style=for-the-badge&logo=linux&logoColor=black)

</div>


<div align="center">
<a href="https://pypi.org/project/dark-web-scraper" target="_blank">
    <img src="https://img.shields.io/pypi/v/dark-web-scraper?color=%2334D058&label=pypi%20package" alt="Package version">
</a>
<a href="https://pypi.org/project/dark-web-scraper" target="_blank">
    <img src="https://img.shields.io/pypi/pyversions/dark-web-scraper.svg?color=%2334D058" alt="Supported Python versions">
</a>
<a href="http://badges.mit-license.org" target="_blank">
    <img src="http://img.shields.io/:license-mit-blue.svg?style=flat-square)" alt="Supported Python versions">
</a>
  
</div>

## Usage :

Currently this is only designed to
- Scrape dark web for onion links
- Scrape images from dark web

## Features to be added :
- [ ] Scraping videos from dark web sites
- [ ] Object detection in images
- [ ] Sentiment aAnalysis on the webpage contents

